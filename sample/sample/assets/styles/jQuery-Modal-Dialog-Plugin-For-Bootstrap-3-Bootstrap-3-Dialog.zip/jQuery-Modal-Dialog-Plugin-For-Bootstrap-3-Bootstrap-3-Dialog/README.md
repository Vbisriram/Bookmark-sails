bootstrap-dialog
================

Make use of Twitter Bootstrap's modal more monkey-friendly.

See live examples here: <a href="http://nakupanda.github.io/bootstrap3-dialog/">http://nakupanda.github.io/bootstrap3-dialog/</a>

Please note that this project is for <a href="http://getbootstrap.com/"><strong>Twitter Bootstrap 3</strong></a>.

Thanks for <a href="https://github.com/akinoniku">akinoniku</a>'s suggestions on dialog appearance.